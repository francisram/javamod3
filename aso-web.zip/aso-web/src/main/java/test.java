import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class test {
	
	public static void main(String[] args) {
        // Tu cadena de texto JSON
        String cadenaJson = "[{\"id\":1,\"nombre\":\"la ia del futuro\"},{\"id\":2,\"nombre\":\"expos java\"}]";

        // Crear un objeto Gson (puedes reutilizar esto para mejorar el rendimiento)
        Gson gson = new Gson();

        // Convertir la cadena JSON a un array de objetos JsonElement
        JsonArray arrayJson = gson.fromJson(cadenaJson, JsonArray.class);

        // Recorrer el array y obtener los valores de id y nombre
        for (JsonElement elemento : arrayJson) {
            JsonObject jsonObject = elemento.getAsJsonObject();
            int id = jsonObject.get("id").getAsInt();
            String nombre = jsonObject.get("nombre").getAsString();
            System.out.println("ID: " + id + ", Nombre: " + nombre);
        }
    }
}
