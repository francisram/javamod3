package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.CodigoDeSeguridad;

public interface CodigoDeSeguridadDao extends GenericDao<CodigoDeSeguridad> {

	@Override
	default List<CodigoDeSeguridad> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default CodigoDeSeguridad getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default CodigoDeSeguridad insertar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default CodigoDeSeguridad modificar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		
	}

}
