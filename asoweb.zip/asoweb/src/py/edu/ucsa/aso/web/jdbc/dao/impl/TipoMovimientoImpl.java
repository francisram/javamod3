package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.TipoMovimientoDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.TipoMovimiento;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class TipoMovimientoImpl implements TipoMovimientoDao {

	static Statement sts;
	private static List<TipoMovimiento> tiposMovimientos;

	@Override
	public List<TipoMovimiento> listar() {
		// TODO Auto-generated method stub
		return TipoMovimientoDao.super.listar();
	}

	@Override
	public TipoMovimiento getById(Integer id) {
		// TODO Auto-generated method stub

		String query = "SELECT id, codigo, descripcion, estado, tipo_deb_cred	FROM public.tipos_movimiento where id = ?";
		try {
			Connection con = ConexionManager.obtenerConexionPostgres();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				TipoMovimiento tm = new TipoMovimiento();

				tm.setId(rs.getInt("id"));
				tm.setCodigo(rs.getString("codigo"));
				tm.setDescripcion(rs.getString("descripcion"));
				tm.setEstado(rs.getString("estado"));
				tm.setTipoDebCred(rs.getString("tipo_deb_cred"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return TipoMovimientoDao.super.getById(id);
	}

	@Override
	public TipoMovimiento insertar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		return TipoMovimientoDao.super.insertar(objecto);
	}

	@Override
	public TipoMovimiento modificar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		return TipoMovimientoDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		TipoMovimientoDao.super.eliminar(objecto);
	}

}
