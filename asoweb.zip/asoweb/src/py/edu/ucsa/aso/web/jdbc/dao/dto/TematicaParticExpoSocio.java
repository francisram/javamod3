package py.edu.ucsa.aso.web.jdbc.dao.dto;

public class TematicaParticExpoSocio {

}
