package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.RolDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Rol;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class RolImpl implements RolDao{
	
	static Statement sts;
	private static List<Rol> roles;
	private  final String queryBase = "SELECT * FROM roles";

	@Override
	public List<Rol> listar() {
		// TODO Auto-generated method stub
		return RolDao.super.listar();
	}

	@Override
	public Rol getById(Integer id) {
		// TODO Auto-generated method stub
		return RolDao.super.getById(id);
	}

	@Override
	public Rol insertar(Rol objecto) {
		// TODO Auto-generated method stub
		return RolDao.super.insertar(objecto);
	}

	@Override
	public Rol modificar(Rol objecto) {
		// TODO Auto-generated method stub
		return RolDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(Rol objecto) {
		// TODO Auto-generated method stub
		RolDao.super.eliminar(objecto);
	}

}
