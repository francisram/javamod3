package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.TematicaParticExpoSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.TematicaParticExpoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class TematicaParticExpoSocioImpl implements TematicaParticExpoSocioDao{
	
	static Statement sts;
	private static List<TematicaParticExpoSocio> tematicaParticExpoSocios;

	@Override
	public List<TematicaParticExpoSocio> listar() {
		// TODO Auto-generated method stub
		return TematicaParticExpoSocioDao.super.listar();
	}

	@Override
	public TematicaParticExpoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return TematicaParticExpoSocioDao.super.getById(id);
	}

	@Override
	public TematicaParticExpoSocio insertar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return TematicaParticExpoSocioDao.super.insertar(objecto);
	}

	@Override
	public TematicaParticExpoSocio modificar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return TematicaParticExpoSocioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		TematicaParticExpoSocioDao.super.eliminar(objecto);
	}

	
	
}
