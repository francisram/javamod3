package py.edu.ucsa.aso.web.jdbc.dao;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;
import py.edu.ucsa.aso.web.jdbc.dao.impl.DominioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.EstadoSocioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.ExposicionImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.MontoCuotaImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.OpcionImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.PagoCuotaSocioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.ParticExpoSocioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.RolImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.RolUsuarioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.SocioDaoImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.UsuarioImpl;

public class DaoFactory {
	
	public static SocioDao getSocioDao() {
		return new SocioDaoImpl();
	}
	
	public static EstadoSocioDao getEstadoSocioDao() {
		return new EstadoSocioImpl();
	}
	
	public static OpcionDao getOpcionDao() {
		return new OpcionImpl();
	}
	
	public static MontoCuotaDao getMontoCuotaDao() {
		return new MontoCuotaImpl();
	}
	
	public static DominioDao getDominioDao() {
		return new DominioImpl();
	}
	
	public static PagoCuotaSocioDao getPagoCuotaSocioDao() {
		return new PagoCuotaSocioImpl();
	}
	
	public static UsuarioDao getUsuarioDao() {
		return new UsuarioImpl();
	}
	
	public static ExposicionDao getExposicionDao() {
		return new ExposicionImpl();
	}
	
	public static ParticExpoSocioDao getParticExpoSocioDao() {
		return new ParticExpoSocioImpl();
	}
	
	public static RolDao getRolDao() {
		return new RolImpl();
	}
	
	public static RolUsuarioDao getRolUsuarioDao() {
		return new RolUsuarioImpl();
	}
	
}
