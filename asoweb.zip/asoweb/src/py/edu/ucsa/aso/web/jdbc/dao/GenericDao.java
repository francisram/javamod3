package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

public interface GenericDao<T> {
List<T> listar();
T getById(Integer  id);
T insertar(T objecto);
T modificar(T objecto);
void eliminar(T objecto);

}
