package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.MensajeEnviadoSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.MensajeEnviadoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class MensajeEnviadoSocioImpl implements MensajeEnviadoSocioDao {
	
	static Statement sts;
	private static List<MensajeEnviadoSocio> mensajesEnviadosSocios;

	@Override
	public List<MensajeEnviadoSocio> listar() {
		// TODO Auto-generated method stub
		return MensajeEnviadoSocioDao.super.listar();
	}

	@Override
	public MensajeEnviadoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return MensajeEnviadoSocioDao.super.getById(id);
	}

	@Override
	public MensajeEnviadoSocio insertar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		return MensajeEnviadoSocioDao.super.insertar(objecto);
	}

	@Override
	public MensajeEnviadoSocio modificar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		return MensajeEnviadoSocioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		MensajeEnviadoSocioDao.super.eliminar(objecto);
	}

}
