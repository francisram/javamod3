package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.ParticExpoSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Exposicion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.ParticExpoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class ParticExpoSocioImpl implements ParticExpoSocioDao {
	static Statement sts;
	private final String queryBase = "SELECT p.*, s.nombres as nombre_socio , u.usuario as nombre_usuario , e.nombre as evento "
			+ "FROM public.partic_expo_socios as p	"
			+ "join socios as s on p.id_socio = s.id "
			+ "join usuarios as u on p.id_usuario_creacion = u.id "
			+ "join exposiciones as e on e.id = p.id_exposicion   ";

	@Override
	public List<ParticExpoSocio> listar() {
		Connection con = ConexionManager.obtenerConexionPostgres();

		List<ParticExpoSocio> listado = new ArrayList<>();
		try {
			sts = con.createStatement();
			ResultSet rs  = sts.executeQuery(queryBase);
			while (rs.next()) {
				listado.add(setFromDB(rs));
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return listado;
	}

	private ParticExpoSocio setFromDB(ResultSet rs) throws SQLException {
		ParticExpoSocio pe = new ParticExpoSocio();
		pe.setId(rs.getInt("id"));
		Socio s = new Socio();
		s.setId(rs.getInt("id_socio"));
		s.setNombres(rs.getString("nombre_socio"));
		pe.setSocio(s);
		Exposicion expo= new Exposicion();
		expo.setId(rs.getInt("id_exposicion"));
		expo.setNombre(rs.getString("evento"));
		pe.setExposicion(expo);
		Usuario usu = new Usuario();
		usu.setId(rs.getInt("id_usuario_creacion"));
		usu.setUsuario(rs.getString("nombre_usuario"));
		pe.setUsuarioCreacion(usu);
		pe.setCanceloParticipacion(rs.getBoolean("cancelo_participacion"));
		Timestamp timestamp = rs.getTimestamp("fecha_cancelacion");
		if (!rs.wasNull()) {
		    pe.setFechaCancelacion(timestamp.toLocalDateTime());
		} else {
		    pe.setFechaCancelacion(null);
		}

		pe.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
		return pe;
	}

	@Override
	public ParticExpoSocio getById(Integer id) {
		ParticExpoSocio pe = new ParticExpoSocio();
		String query = queryBase + " where p.id = ?";
		Connection con  = ConexionManager.obtenerConexionPostgres();
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				pe = setFromDB(rs);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return pe;
	}

	@Override
	public ParticExpoSocio insertar(ParticExpoSocio p) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			String queryInsert = "INSERT INTO partic_expo_socios("
					+ "	 id_socio, "
					+ "id_exposicion, "
					+ "cancelo_participacion, "
					+ "fecha_cancelacion, "
					+ "fecha_creacion, "
					+ "id_usuario_creacion)"
					+ "	VALUES ( ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(queryInsert,PreparedStatement.RETURN_GENERATED_KEYS);
			ps.setInt(1, p.getSocio().getId());
			ps.setInt(2, p.getExposicion().getId());
			ps.setBoolean(3, p.isCanceloParticipacion());
			/*
			if(p.getFechaCancelacion() == null) {
				ps.setDate(4,  null );
			}else {
				ps.setDate(4,  Date.valueOf(p.getFechaCancelacion()) );
			}
			*/
			ps.setNull(4, Types.TIMESTAMP);
			ps.setTimestamp(5,Timestamp.valueOf(p.getFechaCreacion()) );
			ps.setInt(6, p.getUsuarioCreacion().getId());
			ps.executeUpdate();
			ResultSet rs  = ps.getGeneratedKeys();
			if(rs.next()) {
				int clave = rs.getInt(1);
				p.setId(clave);
				rs.close();
			}
			ps.close();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return p;
	}

	@Override
	public ParticExpoSocio modificar(ParticExpoSocio p) {
		String queryUpdate= "UPDATE public.partic_expo_socios"
				+ "	SET  id_socio=?, "
				+ "id_exposicion=?, "
				+ "cancelo_participacion=?,"
				+ "fecha_cancelacion=?, "
				+ "fecha_creacion=?, "
				+ "id_usuario_creacion=?"
				+ "	WHERE id = ?";
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			PreparedStatement ps  = con.prepareStatement(queryUpdate);
			ps.setInt(1, p.getSocio().getId());
			ps.setInt(2, p.getExposicion().getId());
			ps.setBoolean(3, p.isCanceloParticipacion());
			ps.setTimestamp(4,  Timestamp.valueOf(p.getFechaCancelacion()) );
			ps.setTimestamp(5,  Timestamp.valueOf(p.getFechaCreacion()) );
			ps.setInt(6, p.getUsuarioCreacion().getId());
			ps.setInt(7, p.getId());
			ps.executeUpdate();
			ps.close();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		
		return p;
	}

	@Override
	public void eliminar(ParticExpoSocio p) {
		String queryEliminar="DELETE FROM public.partic_expo_socios"
				+ "	WHERE id = ?";
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			PreparedStatement ps = con.prepareStatement(queryEliminar);
			ps.setInt(1, p.getId());
			ps.execute();
			System.out.println("eliminado correctamente");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}

	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	@Override
	public List<ParticExpoSocio> obtenerParticipacionesPorSocio(Integer idSocio) {
		List<ParticExpoSocio> particiapaciones = new ArrayList<>();
		String query = " where p.id_socio = " + idSocio;
		Connection con  =  ConexionManager.obtenerConexionPostgres();
		try {
			sts = con.createStatement();
			sts.executeQuery(queryBase + query);
			ResultSet rs  = sts.executeQuery(queryBase);
			while (rs.next()) {
				particiapaciones.add(setFromDB(rs));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return particiapaciones;
	}

	@Override
	public ParticExpoSocio ObtenerParticipacion(Integer id, Integer id_socio) {
		
		String query = " where p.id_exposicion = ? and p.id_socio = ?";
		ParticExpoSocio part = new ParticExpoSocio();
		try {
			Connection con  = ConexionManager.obtenerConexionPostgres();
			PreparedStatement ps = con.prepareStatement(queryBase + query);
			ps.setInt(1, id);
			ps.setInt(2, id_socio);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				part = setFromDB(rs);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return part;
	}
	
	

}
