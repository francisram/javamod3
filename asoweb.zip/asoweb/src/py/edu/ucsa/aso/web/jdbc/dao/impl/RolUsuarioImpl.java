package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.RolUsuarioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.RolUsuario;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class RolUsuarioImpl implements RolUsuarioDao {
	
	static Statement sts;
	private static List<RolUsuario> rolesUsuarios;

	@Override
	public List<RolUsuario> listar() {
		// TODO Auto-generated method stub
		return RolUsuarioDao.super.listar();
	}

	@Override
	public RolUsuario getById(Integer id) {
		// TODO Auto-generated method stub
		return RolUsuarioDao.super.getById(id);
	}

	@Override
	public RolUsuario insertar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		return RolUsuarioDao.super.insertar(objecto);
	}

	@Override
	public RolUsuario modificar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		return RolUsuarioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		RolUsuarioDao.super.eliminar(objecto);
	}

}
