package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.TematicaParticExpoSocio;

public interface TematicaParticExpoSocioDao extends GenericDao<TematicaParticExpoSocio>{

	@Override
	default List<TematicaParticExpoSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TematicaParticExpoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TematicaParticExpoSocio insertar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TematicaParticExpoSocio modificar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(TematicaParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}
