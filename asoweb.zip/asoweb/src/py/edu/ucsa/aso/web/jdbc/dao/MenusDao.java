package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Menus;

public interface MenusDao extends GenericDao<Menus> {

	@Override
	default List<Menus> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menus getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menus insertar(Menus objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menus modificar(Menus objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Menus objecto) {
		// TODO Auto-generated method stub
		
	}
	

}
