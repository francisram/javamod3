package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;import py.edu.ucsa.aso.web.jdbc.dao.dto.Rol;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public interface UsuarioDao extends GenericDao<Usuario> {
	
	List<Rol> getRolesByUsuario(Integer idUsuario);
	
	public Usuario validarUsuario(String username, String password) ;
	@Override
	default List<Usuario> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Usuario getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Usuario insertar(Usuario objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Usuario modificar(Usuario objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Usuario objecto) {
		// TODO Auto-generated method stub
		
	}

}
