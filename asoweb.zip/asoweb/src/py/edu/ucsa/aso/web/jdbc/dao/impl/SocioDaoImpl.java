package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.SocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Opcion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class SocioDaoImpl implements SocioDao {

	static Statement sts;
	private static List<Socio> socios;
	//private static Connection con = ConexionManager.obtenerConexionPostgres();

	public static List<Socio> getListaSocios() {
		if (Objects.isNull(socios)) {
			socios = new ArrayList<>();
		}
		return socios;
	}

	@Override
	public List<Socio> listar() {
		String query = "select * from socios";
		
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			while (rs.next()) {
				//Socio socio = setDatosFromDB(rs);
				getListaSocios().add(getDatosFromDB(rs));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);
		return socios;
	}

	private Socio getDatosFromDB(ResultSet rs) throws SQLException {
		Socio socio = new Socio();
		socio.setId(rs.getInt("id"));
		socio.setNombres(rs.getString("nombres"));
		socio.setApellidos(rs.getString("apellidos"));
		socio.setEmail(rs.getString("email"));
		socio.setNroSocio(rs.getInt("nro_socio"));
		socio.setNroCedula(rs.getInt("nro_cedula"));
		socio.setFechaIngreso(rs.getDate("fecha_ingreso").toLocalDate());
		OpcionImpl oImpl = new OpcionImpl();
		Opcion estado = oImpl.getById(rs.getInt("id_estado_actual"));
		socio.setEstadoActual(estado);
		socio.setFundador(rs.getBoolean("fundador"));
		Usuario user = new Usuario(rs.getInt("id_usuario_creacion"));
		socio.setUsuarioCreacion(user);
		socio.setFecha_creacion(rs.getDate("fecha_creacion").toLocalDate());
		Socio proponente = new Socio(rs.getInt("id_socio_proponente"));
		socio.setSocioProponente(proponente);
		Opcion tipoSocio = new Opcion(rs.getInt("id_tipo_socio"));
		socio.setTipoSocio(tipoSocio);
		return socio;
	}

	@Override
	public Socio getById(Integer id) {
		Socio socio = new Socio();
		PreparedStatement ps;
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
		ps = con.prepareStatement("select * from socios where id = ?");
		ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
					return getDatosFromDB(rs);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);
		return socio;
	}

	@Override
	public Socio insertar(Socio socio) {

		PreparedStatement pstmt;
		Connection con = ConexionManager.obtenerConexionPostgres();
		String queryInsert = "INSERT INTO socios(nombres, apellidos, email, nro_socio, nro_cedula, fecha_ingreso, id_estado_actual, fecha_estado_actual, fundador, id_usuario_creacion, fecha_creacion, id_socio_proponente, id_tipo_socio) "
				+ "	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(queryInsert,PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, socio.getNombres());
			pstmt.setString(2, socio.getApellidos());
			pstmt.setString(3, socio.getEmail());
			pstmt.setInt(4, socio.getNroSocio());
			pstmt.setInt(5, socio.getNroCedula());
			pstmt.setDate(6, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setInt(7, socio.getEstadoActual().getId());
			pstmt.setDate(8, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setBoolean(9, socio.isFundador());
			pstmt.setInt(10, socio.getUsuarioCreacion().getId());
			pstmt.setDate(11, Date.valueOf(socio.getFecha_creacion()));
			pstmt.setNull(12, Types.INTEGER);
			pstmt.setNull(13, Types.INTEGER);
			pstmt.executeUpdate();
			ResultSet rs = pstmt.getGeneratedKeys();
			if(rs.next()) {
				int clave = rs.getInt(1);
				socio.setId(clave);
				rs.close();
			}
			String subSelectEstado = "(SELECT e.id FROM opciones e JOIN dominios d ON e.id_dominio = d.id WHERE d.codigo = 'ESTSOC' AND e.codigo = 'PEN')";
			queryInsert = "INSERT INTO estados_socios (id_socio, id_estado, fecha_estado, "
					+ " id_usuario_creacion, fecha_creacion, observacion) "
					+ "	VALUES (?, "+subSelectEstado +", ?, ?, ?,?)";
			pstmt = con.prepareStatement(queryInsert);
			pstmt.setInt(1, socio.getId());
			pstmt.setDate(2, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setInt(3, socio.getUsuarioCreacion().getId());
			pstmt.setDate(4, Date.valueOf(socio.getFecha_creacion()));
			pstmt.setString(5, "se da de alta como socio");
			pstmt.executeUpdate();
			pstmt.close();
			con.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception e2) {
				System.out.println("error al ejecutar Rollback : " + e2.getMessage());
			}
		}finally {
			ConexionManager.cerrarConexion(con);			
		}
		return socio;
	}

	@Override
	public Socio modificar(Socio socio) {
		PreparedStatement pstmt;
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {		
		con.setAutoCommit(false);
		String selectEstadoACtualEnBD = "(SELECT s.id_estado_actual FROM socios s where s.id = ? ";
		pstmt = con.prepareStatement(selectEstadoACtualEnBD);
		pstmt.setInt(1, socio.getId());
		ResultSet rs = pstmt.executeQuery();
		int idEstadoACtualEnBD  = 0 ;
		if(rs.next()) { 
			 /*el id del estado actual del socio en la db para compar 
			el id del estado que viene para ser actualizado*/
			 idEstadoACtualEnBD = rs.getInt(1);
			rs.close();
		}
		pstmt.close();
		String queryUpdate = "UPDATE  socios set nombres = ?, apellidos = ?, "
				+ "email= ?, nro_socio = ?, nro_cedula = ?, "
				+ "fecha_ingreso = ?, id_estado_actual = ?, "
				+ "fecha_estado_actual = ?, fundador = ?, id_usuario_creacion = ?, "
				+ "fecha_creacion = ?, id_socio_proponente = ?, "
				+ "id_tipo_socio = ? where id = ? ";

			pstmt = con.prepareStatement(queryUpdate,PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, socio.getNombres());
			pstmt.setString(2, socio.getApellidos());
			pstmt.setString(3, socio.getEmail());
			pstmt.setInt(4, socio.getNroSocio());
			pstmt.setInt(5, socio.getNroCedula());
			pstmt.setDate(6, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setInt(7, socio.getEstadoActual().getId());
			pstmt.setDate(8, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setBoolean(9, socio.isFundador());
			pstmt.setInt(10, socio.getUsuarioCreacion().getId());
			pstmt.setDate(11, Date.valueOf(socio.getFecha_creacion()));
			pstmt.setNull(12, Types.INTEGER);
			pstmt.setNull(13, Types.INTEGER);
			pstmt.setInt(14, socio.getId());
			pstmt.executeUpdate();
			pstmt.close();


			if(idEstadoACtualEnBD != socio.getEstadoActual().getId()) {
				//si son diferentes de seben actualizar e insertar en estado socios
			queryUpdate = "INSERT INTO estados_socios (id_socio, id_estado, fecha_estado, "
					+ " id_usuario_creacion, fecha_creacion, observacion) "
					+ "	VALUES (?, ?, ?, ?, ?,?)";
			pstmt = con.prepareStatement(queryUpdate);
			pstmt.setInt(1, socio.getId());
			pstmt.setInt(2, socio.getEstadoActual().getId());
			pstmt.setDate(3, Date.valueOf(socio.getFechaEstadoActual()));
			pstmt.setInt(4, socio.getUsuarioCreacion().getId());
			pstmt.setDate(5, Date.valueOf(socio.getFecha_creacion()));
			pstmt.setString(6, "se actualizado estado socio");
			pstmt.executeUpdate();
			pstmt.close();
			} 
			con.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception e2) {
				System.out.println("error al ejecutar Rollback : " + e2.getMessage());
			}
		}finally {
			ConexionManager.cerrarConexion(con);			
		}
		return socio;
	}

	@Override
	public void eliminar(Socio s) {
		Statement stm;
		String query = "delete from socios where id = " + s.getId();
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			stm = con.createStatement();
			stm.execute(query);
			ConexionManager.cerrarConexion(con);
			System.out.println("socio eliminado");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("usuario no encontrado ");
			e.printStackTrace();
		}finally {
			ConexionManager.cerrarConexion(con);
		}

	}

	@Override
	public Socio getSocioByNroCedula(String nroCedula) {
		Socio socio = new Socio();
		PreparedStatement ps;
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
		ps = con.prepareStatement("select * from socios where nro_cedula = ?");
		ps.setInt(1, Integer.parseInt(nroCedula));
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
					return getDatosFromDB(rs);

			}

			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {		
			ConexionManager.cerrarConexion(con);
		}
		return socio;
	}

}
