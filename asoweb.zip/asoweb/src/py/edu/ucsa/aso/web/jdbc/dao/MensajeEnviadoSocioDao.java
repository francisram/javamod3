package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.MensajeEnviadoSocio;

public interface MensajeEnviadoSocioDao extends GenericDao<MensajeEnviadoSocio> {

	@Override
	default List<MensajeEnviadoSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MensajeEnviadoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MensajeEnviadoSocio insertar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MensajeEnviadoSocio modificar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(MensajeEnviadoSocio objecto) {
		// TODO Auto-generated method stub
		
	}
	

}
