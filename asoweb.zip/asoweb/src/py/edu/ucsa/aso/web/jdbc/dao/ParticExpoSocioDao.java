package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.ParticExpoSocio;

public interface ParticExpoSocioDao extends GenericDao<ParticExpoSocio> {
	
	public ParticExpoSocio ObtenerParticipacion(Integer id ,Integer id_socio);
	
	List<ParticExpoSocio> obtenerParticipacionesPorSocio(Integer idSocio);

	@Override
	default List<ParticExpoSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default ParticExpoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default ParticExpoSocio insertar(ParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default ParticExpoSocio modificar(ParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(ParticExpoSocio objecto) {
		// TODO Auto-generated method stub
		
	}

}
