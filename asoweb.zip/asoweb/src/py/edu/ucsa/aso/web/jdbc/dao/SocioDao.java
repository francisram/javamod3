package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;

public interface SocioDao extends GenericDao<Socio> {
	Socio getSocioByNroCedula(String nroCedula);

	@Override
	default List<Socio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Socio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Socio insertar(Socio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Socio modificar(Socio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Socio objecto) {
		// TODO Auto-generated method stub
		
	}
	
}
