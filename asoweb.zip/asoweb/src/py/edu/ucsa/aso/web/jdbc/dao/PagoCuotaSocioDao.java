package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.PagoCuotaSocio;

public interface PagoCuotaSocioDao  extends GenericDao<PagoCuotaSocio>{

	@Override
	default List<PagoCuotaSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoCuotaSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoCuotaSocio insertar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoCuotaSocio modificar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		
	}

}
