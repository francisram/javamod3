package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.ExposicionDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Exposicion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class ExposicionImpl implements ExposicionDao{
	
	static Statement sts;
	private static List<Exposicion> exposiciones;
	private final String queryBase = "SELECT e.* , u.usuario FROM exposiciones as e join usuarios as u on u.id = e.id_usuario_creacion";

	@Override
	public List<Exposicion> listar() {
		Connection con =  ConexionManager.obtenerConexionPostgres();
		List<Exposicion> listaExposiciones = new ArrayList<>();
		try {
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(queryBase+ " WHERE  e.fecha_expo >= CURRENT_DATE");
			while(rs.next()) {
				 listaExposiciones.add(setFromDB(rs));
			}
			sts.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return listaExposiciones;
	}

	private Exposicion setFromDB(ResultSet rs) throws SQLException {
		Exposicion exp = new Exposicion();
		exp.setContacto(rs.getString("contacto"));
		exp.setDescripcion(rs.getString("descripcion"));
		exp.setFechaCreacion(rs.getDate("fecha_creacion").toLocalDate());
		exp.setFechaExpo(rs.getDate("fecha_expo").toLocalDate());
		exp.setId(rs.getInt("id"));
		exp.setNombre(rs.getString("nombre"));
		exp.setOrganiza(rs.getString("organiza"));
		exp.setUbicacion(rs.getString("ubicacion"));
		Usuario u = new Usuario();
		u.setId(rs.getInt("id_usuario_creacion"));
		u.setUsuario(rs.getString("usuario"));
		exp.setUsuarioCreacion(u);
		return exp;
	}

	@Override
	public Exposicion getById(Integer id) {
		// TODO Auto-generated method stub
		return ExposicionDao.super.getById(id);
	}

	@Override
	public Exposicion insertar(Exposicion objecto) {
		// TODO Auto-generated method stub
		return ExposicionDao.super.insertar(objecto);
	}

	@Override
	public Exposicion modificar(Exposicion objecto) {
		// TODO Auto-generated method stub
		return ExposicionDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(Exposicion objecto) {
		// TODO Auto-generated method stub
		ExposicionDao.super.eliminar(objecto);
	}

	@Override
	public List<Exposicion> listarPorFechas(String fechaInicial, String fechaFinal) {
		Date fecInicial = Date.valueOf(fechaInicial);
		Date fecFinal = Date.valueOf(fechaFinal);
		String query = " where fecha_expo between ? and ?";
		List<Exposicion> listado = new ArrayList<>();
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			PreparedStatement ps = con.prepareStatement( queryBase + query);
			ps.setDate(1, fecInicial);
			ps.setDate(2, fecFinal);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				listado.add(setFromDB(rs));
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}finally {
			ConexionManager.cerrarConexion(con);
		}
	
		return listado;
	}

}
