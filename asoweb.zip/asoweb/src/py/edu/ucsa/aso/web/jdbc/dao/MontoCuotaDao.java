package py.edu.ucsa.aso.web.jdbc.dao;

import py.edu.ucsa.aso.web.jdbc.dao.dto.MontoCuota;

public interface MontoCuotaDao extends GenericDao<MontoCuota> {
	MontoCuota getMontoCuotaByAnho(int mes,int anho);
}
