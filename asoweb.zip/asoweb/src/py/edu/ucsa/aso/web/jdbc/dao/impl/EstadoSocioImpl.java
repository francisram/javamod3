package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.EstadoSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.EstadoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class EstadoSocioImpl implements EstadoSocioDao{
	
	static Statement sts;
	private static List<EstadoSocio> estadosSocios;

	@Override
	public List<EstadoSocio> listar() {
		// TODO Auto-generated method stub
		return EstadoSocioDao.super.listar();
	}

	@Override
	public EstadoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return EstadoSocioDao.super.getById(id);
	}

	@Override
	public EstadoSocio insertar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		return EstadoSocioDao.super.insertar(objecto);
	}

	@Override
	public EstadoSocio modificar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		return EstadoSocioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		EstadoSocioDao.super.eliminar(objecto);
	}

}
