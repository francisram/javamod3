package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Menu;

public interface MenuDao extends GenericDao<Menu> {

	@Override
	default List<Menu> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menu getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menu insertar(Menu objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Menu modificar(Menu objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Menu objecto) {
		// TODO Auto-generated method stub
		
	}
	

}
