package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.OpcionDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Dominio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Opcion;

public class OpcionImpl implements OpcionDao {

	static Statement sts;
	private static List<Opcion> opciones;

	private final String queryBase = "select o.* ,d.codigo cod_dominio ,"
			+ " d.descripcion desc_dominio , "
			+ "padre.codigo cod_opcion_padre , "
			+ "padre.descripcion desc_opcion_padre "
			+ "from opciones o "
			+ "JOIN dominios d ON o.id_dominio = d.id "
			+ "LEFT OUTER JOIN opciones padre ON o.id_opcion_padre = padre.id ";

	public List<Opcion> getListaOpciones() {
		if (Objects.isNull(opciones)) {
			opciones = new ArrayList<>();
		}
		return opciones;
	}

	@Override
	public Opcion getOpcionByDominioCodOpcion(String dominio, String codOpcion) {
		Opcion opcion = null;
		Connection c = ConexionManager.obtenerConexionPostgres();
		PreparedStatement s;
		try {

			String selectStmt = queryBase + "WHERE d.codigo = ? and o.codigo = ?";

			s = c.prepareStatement(selectStmt);
			s.setString(1, dominio);
			s.setString(2, codOpcion);
			ResultSet rs = s.executeQuery(selectStmt);
			if (rs.next()) {
				opcion = getDataFromDB(rs);
			}
			rs.close();
			s.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConexionManager.cerrarConexion(c);
		}
		return opcion;
	}

	@Override
	public List<Opcion> listar() {
		Connection con = ConexionManager.obtenerConexionPostgres();
		List<Opcion> listaOpciones = new ArrayList<>();
		try {
			//String query = "SELECT * FROM opciones ORDER BY id ASC ";
			String query = queryBase + " order by descripcion asc";
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			
			while (rs.next()) {
				//Opcion op = getDataFromDB(rs);
				listaOpciones.add(getDataFromDB(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionManager.cerrarConexion(con);
		}

		return listaOpciones;
	}

	private Opcion getDataFromDB(ResultSet rs) throws SQLException {

		Opcion op = new Opcion();
		op.setId(rs.getInt("id"));
		op.setCodigo(rs.getString("codigo"));
		op.setDescripcion(rs.getString("descripcion"));
		op.setEstado(rs.getString("estado"));
		Dominio dominio = new Dominio(rs.getInt("id_dominio"));
		dominio.setDescripcion(rs.getString("desc_dominio"));
		op.setDominio(dominio);
		if(Objects.nonNull(rs.getObject("id_opcion_padre"))) {
			Opcion opcPadre = new Opcion();
			opcPadre.setId(rs.getInt("id_opcion_padre"));
			opcPadre.setCodigo(rs.getString("cod_opcion_padre"));
			opcPadre.setDescripcion(rs.getString("desc_opcion_padre"));
			op.setPadre(opcPadre);		
		}
		return op;
	}

	@Override
	public Opcion getById(Integer id) {
		Opcion opcion = new Opcion();
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			String query = queryBase + " where o.id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				opcion = getDataFromDB(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		return opcion;
	}

	@Override
	public Opcion insertar(Opcion op) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			String queryInsert = "INSERT INTO public.opciones("
					+ "	id_dominio, codigo, descripcion, estado, id_opcion_padre)" + "	VALUES (?, ?, ?, ?, ?);";
			PreparedStatement ps = con.prepareStatement(queryInsert);
			// ps.setInt(1,op.getId() );
			setValoresParaGuardar(op, ps);
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			if (rs.next()) {
				int clave = rs.getInt(1);
				op.setId(clave);
				rs.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConexionManager.cerrarConexion(con);
		}

		return op;

	}

	private void setValoresParaGuardar(Opcion op, PreparedStatement ps) throws SQLException {
		if (Objects.nonNull(op.getDominio().getId())) {
			ps.setInt(1, op.getDominio().getId());
		} else {
			ps.setNull(1, Types.INTEGER);
		}
		ps.setString(2, op.getCodigo());
		ps.setString(3, op.getDescripcion());
		ps.setString(4, op.getEstado());
		if(Objects.nonNull(op.getPadre().getId())) {
			ps.setInt(5, op.getPadre().getId());			
		}else {
			ps.setNull(5, Types.INTEGER);
		}
	}

	@Override
	public Opcion modificar(Opcion objecto) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			String queryUpdate = "UPDATE opciones SET  id_dominio=?, codigo=?, descripcion=?, estado=?, id_opcion_padre=?"
					+ "	WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(queryUpdate);
			setValoresParaGuardar(objecto, ps);
			ps.setInt(6, objecto.getId());
			ps.executeUpdate();
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionManager.cerrarConexion(con);
		}
		return objecto;
	}

	@Override
	public void eliminar(Opcion objecto) {
		// TODO Auto-generated method stub
		OpcionDao.super.eliminar(objecto);
	}

	@Override
	public List<Opcion> getOpcionesByCodDominio(String dominio) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		String query = queryBase + " where upper(d.codigo) =  Upper(?) order by descripcion asc";
		List<Opcion> listaOpciones =  new ArrayList<>();
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, dominio );
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Opcion op = getDataFromDB(rs);
				listaOpciones.add(op);
			}
			rs.close();
			ps.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConexionManager.cerrarConexion(con);
		}
		return listaOpciones;
	}

	@Override
	public List<Opcion> getOpcionesByIdDominio(Integer idDominio) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		String query = queryBase + " where d.id =  ? order by descripcion asc";
		List<Opcion> listaOpciones =  new ArrayList<>();
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, idDominio );
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Opcion op = getDataFromDB(rs);
				listaOpciones.add(op);
			}
			rs.close();
			ps.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConexionManager.cerrarConexion(con);
		}
		return listaOpciones;
	}

}
