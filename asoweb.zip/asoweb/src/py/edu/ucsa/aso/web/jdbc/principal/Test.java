package py.edu.ucsa.aso.web.jdbc.principal;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Dominio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Exposicion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.MontoCuota;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Opcion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.PagoCuotaSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.ParticExpoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Rol;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;
import py.edu.ucsa.aso.web.jdbc.dao.impl.DominioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.ExposicionImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.MontoCuotaImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.OpcionImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.PagoCuotaSocioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.ParticExpoSocioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.SocioDaoImpl;
import py.edu.ucsa.aso.web.jdbc.dao.impl.UsuarioImpl;
import py.edu.ucsa.aso.web.jdbc.dao.util.Consola;

public class Test {

	public static void main(String[] args) {

		 //listarSocios();
		// buscarSocioPorId();
		// buscarSocioPorCedula();
		// insertarNuevoScocio();
		// actualizarPorId();
		// eliminar();
		// listarCuotas();
		// listarCuotas();
		// listarUsuarios();
		// buscarUsuarioPorId();
		 //listarDominios();
		 //listarOpciones();
		//listarOpcionesPorCodDominio();
		//insertarOpcion();
		//opcionesByCodDominioOpcion("tipsoc");
		//opcionesByCodDominioOpcion("estsoc");
		//listarPagosCuotaSocio();
		//listarParticipaciones();
		//listarRolesPorUsuario();
		ParticExpoSocioImpl pimpl = new ParticExpoSocioImpl();
		List<ParticExpoSocio> listado = pimpl.listar();
		listado.forEach((x)->System.out.println(x));
		 

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>> opciones <<<<<<<<<<<<<<<
	public static void listarOpciones() {
		List<Opcion> opciones = new ArrayList<>();
		OpcionImpl opImpl = new OpcionImpl();
		opciones = opImpl.listar();
		opciones.forEach(x -> System.out.println(x));
	}

	public static void listarOpcionesPorCodDominio() {
		List<Opcion> opciones = new ArrayList<>();
		OpcionImpl opImpl = new OpcionImpl();
		opciones = opImpl
				.getOpcionesByCodDominio(Consola.leerDatos("ingrese id del dominio  a buscar en opcion:  ").trim());
		opciones.forEach(x -> System.out.println(x));
	}

	public static void insertarOpcion() {
		Opcion opcion = new Opcion();
		opcion.setCodigo("CHI");
		opcion.setDescripcion("CHILE");
		Dominio dom = new Dominio();
		dom.setId(1);
		opcion.setDominio(dom);
		opcion.setEstado("A");
		Opcion padre = new Opcion();
		padre.setId(1);
		opcion.setPadre(padre);
		OpcionImpl opImpl = new OpcionImpl();
		opImpl.insertar(opcion);
	}

	
	public static void opcionesByCodDominioOpcion(String codigo) {
		List<Opcion> opciones =  new ArrayList<>();
		OpcionImpl oImpl = new OpcionImpl();
		opciones = oImpl.getOpcionesByCodDominio(codigo);
		System.out.println(opciones);
	}
	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> dominios <<<<<<<<<<<<<<<<<
	public static void listarDominios() {
		DominioImpl domImpl = new DominioImpl();
		List<Dominio> doms = domImpl.listar();
		doms.forEach(x -> System.out.println(x));
	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> usuarios <<<<<<<<<<<<<<<<<<<<<
	public static void listarUsuarios() {
		UsuarioImpl usuImpl = new UsuarioImpl();
		List<Usuario> usuarios = usuImpl.listar();
		usuarios.forEach(x -> System.out.println(x.toString()));
	}

	public static void buscarUsuarioPorId() {
		Integer indice = Integer.parseInt(Consola.leerDatos("ingrese id a buscar :  ").trim());
		UsuarioImpl uImpl = new UsuarioImpl();
		Usuario u = new Usuario();

		u = uImpl.getById(indice);
		System.out.println(u.toString());

	}

	// >>>>>>>>>>>> pago cuotas <<<<<<<<<<<<<<<<
	public static void listarPagosCuotaSocio() {
		PagoCuotaSocioImpl pCuotaImpl = new PagoCuotaSocioImpl();
		List<PagoCuotaSocio> pCuotas = pCuotaImpl.listar();
		pCuotas.forEach((x)->System.out.println(x));

	}

	public static void buscarPagoPorId() {
		Integer indice = Integer.parseInt(Consola.leerDatos("ingrese id a buscar :  ").trim());
		PagoCuotaSocioImpl pCuotaImpl = new PagoCuotaSocioImpl();
		PagoCuotaSocio pCuota = pCuotaImpl.getById(indice);
		System.out.println(pCuota);
	}

	// >>>>>>>>>>>>>>>> socios <<<<<<<<<<<<<<<<<<<
	public static void buscarSocioPorCedula() {
		SocioDaoImpl socioImpl = new SocioDaoImpl();
		Socio socio = socioImpl.getSocioByNroCedula(Consola.leerDatos("ingrese cedula del socio a buscar: ").trim());
		System.out.println(socio.toString());
	}

	public static void buscarSocioPorId() {
		SocioDaoImpl socioImpl = new SocioDaoImpl();
		Integer indice = Integer.parseInt(Consola.leerDatos("ingrese id a buscar :  ").trim());
		Socio socio = socioImpl.getById(indice);
		System.out.println(socio.toString());
	}

	public static void insertarNuevoScocio() {
		Socio ns = new Socio();

		SocioDaoImpl socioImpl = new SocioDaoImpl();
		System.out.println("registrar nuevo socio");
		String nombres = "fran"; // Consola.leerDatos("nombres: ");
		ns.setNombres(nombres);
		String apellidos = "lopez"; // Consola.leerDatos("apellidos: ");
		ns.setApellidos(apellidos);
		String email = "asdasd@test"; // Consola.leerDatos("email: ");
		ns.setEmail(email);
		String nro_socio = "5555";// Consola.leerDatos("nro_socio: ");
		ns.setNroSocio(Integer.parseInt(nro_socio));
		String nro_cedula = "4444"; // Consola.leerDatos("nro_cedula: ");
		ns.setNroCedula(Integer.parseInt(nro_cedula));
		String fecha_ingreso = "2023-07-22"; // Consola.leerDatos("fecha_ingreso( año-mes-dia ): ");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-d");
		LocalDate localDate = LocalDate.parse(fecha_ingreso, formatter);
		ns.setFechaIngreso(localDate);
		// String id_estado_actual = Consola.leerDatos("id_estado_actual: ");
		Opcion estadoActual = new Opcion(Integer.parseInt("1" /* Consola.leerDatos("id_estado_actual: ") */));
		ns.setEstadoActual(estadoActual);
		ns.setFechaEstadoActual(LocalDateTime.now().toLocalDate());
		String fundador = "no"; // Consola.leerDatos("fundador? si / no :");
		ns.setFundador(fundador == "si" ? true : false);
		Usuario usuario = new Usuario(Integer.parseInt("1" /* Consola.leerDatos("id_usuario_creacion : ") */));
		ns.setUsuarioCreacion(usuario);
		ns.setFecha_creacion(LocalDateTime.now().toLocalDate());
		System.out.println(ns.toString());
		Socio socio = socioImpl.insertar(ns);

		if (socio != null) {
			System.out.println("se ha insertado un nuevo socio:" + socio.toString());
		} else {
			System.out.println("no se pudo registrar al socio");
		}

	}

	public static void listarSocios() {
		SocioDaoImpl sI = new SocioDaoImpl();
		List<Socio> listado = sI.listar();
		listado.forEach((x) -> System.out.println(x));

	}

	public static void actualizarPorId() {
		SocioDaoImpl socioImpl = new SocioDaoImpl();
		Socio s = socioImpl.getById(Integer.parseInt(Consola.leerDatos("Ingrese id del socio")));
		if (s.getId() != 0) {
			System.out.println("actualizar socio");
			String nombres = Consola.leerDatos("nombres : " + s.getNombres() + " por: ");
			Socio ns = new Socio();
			ns.setNombres(nombres);
			String apellidos = Consola.leerDatos("apellidos : " + s.getApellidos() + " por: ");
			ns.setApellidos(apellidos);
			String email = Consola.leerDatos("email :" + s.getEmail() + " por: ");
			ns.setEmail(email);
			ns.setNroSocio(Integer.parseInt(Consola.leerDatos("N° socio :" + s.getNroSocio() + " por: ")));
			ns.setNroCedula(Integer.parseInt(Consola.leerDatos("cedula: " + s.getNroCedula() + " por: ")));
			String fecha_ingreso = Consola.leerDatos("fecha de ingreso:" + s.getFechaIngreso() + " por: ");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-d");
			LocalDate localDate = LocalDate.parse(fecha_ingreso, formatter);
			ns.setFechaIngreso(localDate);
			// String id_estado_actual = Consola.leerDatos("id estado actual
			// :"+s.getId_estado_actual()+" por: ");
			Opcion estadoActual = new Opcion(
					Integer.parseInt(Consola.leerDatos("id estado actual :" + s.getEstadoActual() + " por: ")));
			ns.setEstadoActual(estadoActual);
			ns.setFechaEstadoActual(LocalDateTime.now().toLocalDate());
			String fundador = Consola.leerDatos("fundador? " + (s.isFundador() == true ? "si" : "no") + " por: ");
			ns.setFundador(fundador == "si" ? true : false);
			// String id_usuario_creacion = Consola.leerDatos("id usuario creador:
			// "+s.getUsuarioCreacion()+" por: ");
			Usuario uc = new Usuario(
					Integer.parseInt(Consola.leerDatos("id usuario creador: " + s.getUsuarioCreacion() + " por: ")));
			ns.setUsuarioCreacion(uc);
			ns.setFecha_creacion(LocalDateTime.now().toLocalDate());
			ns.setId(s.getId());
			System.out.println(ns.toString());
			Socio socio = socioImpl.modificar(s);

		} else {
			System.out.println("no se encuentra socio");
		}

	}

	public static void eliminar() {
		int id = Integer.parseInt(Consola.leerDatos("ingrese id : "));
		SocioDaoImpl simpl = new SocioDaoImpl();
		Socio s = new Socio();
		simpl.eliminar(s);
	}

	public static void listarCuotas() {
		MontoCuotaImpl mtimpl = new MontoCuotaImpl();
		List<MontoCuota> cuotas = mtimpl.listar();
		cuotas.forEach((x) -> System.out.println(x));
	}

	public static void listarParticipaciones() {
		ParticExpoSocioImpl pImpl = new ParticExpoSocioImpl();
		List<ParticExpoSocio> participantes = pImpl.listar();
		participantes.forEach((x)->System.out.println(x));
	}
	
	public static void listarRolesPorUsuario() {
		UsuarioImpl u = new UsuarioImpl();
		List<Rol> listado = u.getRolesByUsuario(2);
		listado.forEach((x)->System.out.println(x));
	}
}
