package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.UsuarioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Rol;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class UsuarioImpl implements UsuarioDao {
	static Statement sts;
	private static List<Usuario> usuarios;
	
	@Override
	public Usuario validarUsuario(String username, String password) {
		Usuario user = new Usuario();		
		try {
			Connection con  =  ConexionManager.obtenerConexionPostgres();
			String query = "select * from usuarios where usuario = ? and clave = ? and habilitado = true and cuenta_bloqueada = false";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				user = getDataFromDB(rs);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return user;
	}

	public List<Usuario> getListaDeUsuario() {
		if (Objects.isNull(usuarios)) {
			usuarios = new ArrayList<>();
		}
		return usuarios;
	}

	@Override
	public List<Usuario> listar() {
		try {
			String query = "select * from usuarios";
			Connection con = ConexionManager.obtenerConexionPostgres();
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			while (rs.next()) {
				// Usuario u = getDataFromDB(rs);
				getListaDeUsuario().add(getDataFromDB(rs));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return usuarios;
	}

	private Usuario getDataFromDB(ResultSet rs) throws SQLException {
		Usuario u = new Usuario();
		u.setId(rs.getInt("id"));
		u.setUsuario(rs.getString("usuario"));
		u.setEmail(rs.getString("email"));
		u.setClave(rs.getString("clave"));
		u.setHabilitado(rs.getBoolean("habilitado"));
		u.setCuentaBloqueada(rs.getBoolean("cuenta_bloqueada"));
		u.setCuentaExpirada(rs.getBoolean("cuenta_expirada"));
		u.setFechaCreacionUsuario(rs.getDate("fecha_creacion_usuario").toLocalDate());
		Socio s = new Socio(rs.getInt("id_socio"));
		u.setIdSocio(s);
		return u;
	}

	@Override
	public Usuario getById(Integer id) {
		Usuario usu = new Usuario();
		try {
			Connection con = ConexionManager.obtenerConexionPostgres();
			String query = "select * from usuarios where id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				usu = getDataFromDB(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return usu;
	}

	@Override
	public Usuario insertar(Usuario u) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		String queryInsert = "INSERT INTO usuarios(" + "id, usuario, email, clave, habilitado, "
				+ "cuenta_bloqueada, cuenta_expirada, fecha_creacion_usuario, id_socio)"
				+ "	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement ps = con.prepareStatement(queryInsert);
			// ps.setInt(1,u.getId() );
			ps.setString(2, u.getUsuario());
			ps.setString(3, u.getEmail());
			ps.setString(4, u.getClave());
			ps.setBoolean(5, u.isHabilitado());
			ps.setBoolean(6, u.isCuentaBloqueada());
			ps.setBoolean(7, u.isCuentaExpirada());
			ps.setDate(8, Date.valueOf(u.getFechaCreacionUsuario()));
			ps.setInt(9, u.getIdSocio().getId());
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			if (rs.next()) {
				int clave = rs.getInt(1);
				u.setId(clave);
				rs.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public Usuario modificar(Usuario u) {
		try {
			Connection con = ConexionManager.obtenerConexionPostgres();
			String queryUpdate = "UPDATE usuarios SET usuario=?, email=?, clave=?, habilitado=?, cuenta_bloqueada=?, "
					+ "cuenta_expirada=?, fecha_creacion_usuario=?, id_socio=?	WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(queryUpdate);
			ps.setString(1, u.getUsuario());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getClave());
			ps.setBoolean(4, u.isHabilitado());
			ps.setBoolean(5, u.isCuentaBloqueada());
			ps.setBoolean(6, u.isCuentaExpirada());
			ps.setDate(7, Date.valueOf(u.getFechaCreacionUsuario()));
			ps.setInt(8, u.getIdSocio().getId());
			ps.setInt(9, u.getId());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return u;
	}

	@Override
	public void eliminar(Usuario objecto) {
		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			String queryDelete = "delete from usuarios where id = ?";
			PreparedStatement ps = con.prepareStatement(queryDelete);
			ps.setInt(1, objecto.getId());
			ps.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);

	}

	@Override
	public List<Rol> getRolesByUsuario(Integer idUsuario) {
		String query = "SELECT * FROM roles_usuarios where id_usuario = " + idUsuario;
		//System.out.println(query);
		Connection con  = ConexionManager.obtenerConexionPostgres();
		List<Rol> roles = new ArrayList<>();
		try {
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			while(rs.next()) {
				Rol rol = new Rol();
				rol.setIdUsuario(rs.getInt("id_usuario"));
				rol.setRol(rs.getInt("id_rol"));
				roles.add(rol);
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return roles;
	}

}
