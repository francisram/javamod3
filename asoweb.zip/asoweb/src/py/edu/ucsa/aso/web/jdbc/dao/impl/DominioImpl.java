package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.DominioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Dominio;

public class DominioImpl implements DominioDao {

	static Statement sts;
	private static List<Dominio> dominios;

	public List<Dominio> getListaDominios() {
		if (Objects.isNull(dominios)) {
			dominios = new ArrayList<>();
		}
		return dominios;
	}

	@Override
	public List<Dominio> listar() {
		try {
			String query = "SELECT * FROM public.dominios";
			Connection con = ConexionManager.obtenerConexionPostgres();
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			while (rs.next()) {
				Dominio dom = getDataFromDB(rs);
				getListaDominios().add(dom);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dominios;
	}

	private Dominio getDataFromDB(ResultSet rs)throws SQLException  {
		Dominio dom = new Dominio();
		dom.setId(rs.getInt("id"));
		dom.setCodigo(rs.getString("codigo"));
		dom.setDescripcion(rs.getString("descripcion"));
		Dominio dPadre = new Dominio(rs.getInt("id_dominio_padre"));
		//dPadre.setId(rs.getInt(rs.getInt("id_dominio_padre")));
		dom.setEstado(rs.getString("estado"));
		dom.setDominioPadre(dPadre);
		return dom;
	}

	@Override
	public Dominio getById(Integer id) {
		// TODO Auto-generated method stub
		return DominioDao.super.getById(id);
	}

	@Override
	public Dominio insertar(Dominio objecto) {
		// TODO Auto-generated method stub
		return DominioDao.super.insertar(objecto);
	}

	@Override
	public Dominio modificar(Dominio objecto) {
		// TODO Auto-generated method stub
		return DominioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(Dominio objecto) {
		// TODO Auto-generated method stub
		DominioDao.super.eliminar(objecto);
	}

}
