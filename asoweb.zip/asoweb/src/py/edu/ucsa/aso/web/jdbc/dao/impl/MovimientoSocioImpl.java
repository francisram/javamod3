package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.MovimientoSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.MovimientoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class MovimientoSocioImpl implements MovimientoSocioDao {
	static Statement sts;
	private static List<MovimientoSocio> movimientosSocios;

	@Override
	public List<MovimientoSocio> listar() {
		// TODO Auto-generated method stub
		return MovimientoSocioDao.super.listar();
	}

	@Override
	public MovimientoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return MovimientoSocioDao.super.getById(id);
	}

	@Override
	public MovimientoSocio insertar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		return MovimientoSocioDao.super.insertar(objecto);
	}

	@Override
	public MovimientoSocio modificar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		return MovimientoSocioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		MovimientoSocioDao.super.eliminar(objecto);
	}

}
