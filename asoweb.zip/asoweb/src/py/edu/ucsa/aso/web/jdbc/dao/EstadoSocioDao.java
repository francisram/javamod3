package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.EstadoSocio;

public interface EstadoSocioDao extends GenericDao<EstadoSocio> {

	@Override
	default List<EstadoSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default EstadoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default EstadoSocio insertar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default EstadoSocio modificar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(EstadoSocio objecto) {
		// TODO Auto-generated method stub
		
	}

}
