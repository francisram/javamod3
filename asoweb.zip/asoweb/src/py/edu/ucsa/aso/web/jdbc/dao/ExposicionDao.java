package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Exposicion;

public interface ExposicionDao extends GenericDao<Exposicion> {
	
	List<Exposicion> listarPorFechas(String fechaInicial , String fechaFinal);

	@Override
	default List<Exposicion> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Exposicion getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Exposicion insertar(Exposicion objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Exposicion modificar(Exposicion objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Exposicion objecto) {
		// TODO Auto-generated method stub
		
	}

}
