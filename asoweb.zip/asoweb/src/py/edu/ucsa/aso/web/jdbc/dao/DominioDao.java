package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Dominio;

public interface DominioDao extends GenericDao<Dominio> {

	@Override
	default List<Dominio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Dominio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Dominio insertar(Dominio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Dominio modificar(Dominio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Dominio objecto) {
		// TODO Auto-generated method stub
		
	}

}
