package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.RolUsuario;

public interface RolUsuarioDao extends GenericDao<RolUsuario>{

	@Override
	default List<RolUsuario> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default RolUsuario getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default RolUsuario insertar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default RolUsuario modificar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(RolUsuario objecto) {
		// TODO Auto-generated method stub
		
	}

}
