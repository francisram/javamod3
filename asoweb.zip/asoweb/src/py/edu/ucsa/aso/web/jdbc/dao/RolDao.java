package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Rol;

public interface RolDao extends GenericDao<Rol> {

	@Override
	default List<Rol> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Rol getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Rol insertar(Rol objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Rol modificar(Rol objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Rol objecto) {
		// TODO Auto-generated method stub
		
	}

}
