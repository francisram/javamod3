package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.GenericDao;
import py.edu.ucsa.aso.web.jdbc.dao.PagoOtroConceptoDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.PagoOtroConcepto;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class PagoOtroConceptoImpl implements PagoOtroConceptoDao {
	static Statement sts;
	private static List<PagoOtroConcepto> pagosOtrosConceptos;

	@Override
	public List<PagoOtroConcepto> listar() {
		// TODO Auto-generated method stub
		return PagoOtroConceptoDao.super.listar();
	}

	@Override
	public PagoOtroConcepto getById(Integer id) {
		// TODO Auto-generated method stub
		return PagoOtroConceptoDao.super.getById(id);
	}

	@Override
	public PagoOtroConcepto insertar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		return PagoOtroConceptoDao.super.insertar(objecto);
	}

	@Override
	public PagoOtroConcepto modificar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		return PagoOtroConceptoDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		PagoOtroConceptoDao.super.eliminar(objecto);
	}

	
	
}
