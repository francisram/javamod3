package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.CodigoDeSeguridadDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.CodigoDeSeguridad;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class CodigoDeSeguridadImpl implements CodigoDeSeguridadDao{
	static Statement sts;
	private static List<CodigoDeSeguridad> codigosDeSeguridad;

	@Override
	public List<CodigoDeSeguridad> listar() {
		// TODO Auto-generated method stub
		return CodigoDeSeguridadDao.super.listar();
	}

	@Override
	public CodigoDeSeguridad getById(Integer id) {
		// TODO Auto-generated method stub
		return CodigoDeSeguridadDao.super.getById(id);
	}

	@Override
	public CodigoDeSeguridad insertar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		return CodigoDeSeguridadDao.super.insertar(objecto);
	}

	@Override
	public CodigoDeSeguridad modificar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		return CodigoDeSeguridadDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(CodigoDeSeguridad objecto) {
		// TODO Auto-generated method stub
		CodigoDeSeguridadDao.super.eliminar(objecto);
	}

}
