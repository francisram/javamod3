package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.MontoCuotaDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.MontoCuota;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class MontoCuotaImpl implements MontoCuotaDao {
	static Statement sts;
	public static List<MontoCuota> listadoCuotas;
	
	public List<MontoCuota> getListadoMontoCuotas(){
		if (Objects.isNull(listadoCuotas)) {
			listadoCuotas = new ArrayList<>();
		}
		return listadoCuotas;
	}

	@Override
	public List<MontoCuota> listar() {
		String query = "select * from montos_cuota order by fecha_inicio_vigencia desc";

		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			Statement sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);

			while (rs.next()) {
				MontoCuota mt = getDatosFromDB(rs);
				getListadoMontoCuotas().add(mt);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);
		return listadoCuotas;
	}

	private MontoCuota getDatosFromDB(ResultSet rs) throws SQLException {
		MontoCuota mt = new MontoCuota();
		mt.setEstado(rs.getString("estado"));
		mt.setFechaCreacion((rs.getTimestamp("fecha_creacion").toLocalDateTime()));
		mt.setFechaFinVigencia((rs.getTimestamp("fecha_fin_vigencia").toLocalDateTime()));
		mt.setFechaInactivacion((rs.getTimestamp("fecha_inactivacion").toLocalDateTime()));
		mt.setFechaInicioVigencia((rs.getTimestamp("fecha_inicio_vigencia").toLocalDateTime()));
		mt.setId(rs.getInt("id"));
		mt.setMonto(rs.getInt("monto"));
		Usuario inactivacion = new Usuario(rs.getInt("id_usuario_inactivacion"));
		mt.setUsuarioInactivacion(inactivacion);
		return mt;
	}

	@Override
	public MontoCuota getById(Integer id) {
		String query = "select * from montos_cuota where id = ?";

		Connection con = ConexionManager.obtenerConexionPostgres();
		MontoCuota mt = new MontoCuota();
		PreparedStatement ps ;
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				/*
				mt.setEstado(rs.getString("estado"));
				mt.setFechaCreacion(LocalDateTime.parse(rs.getString("fecha_ingreso"),DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
				mt.setFechaFinVigencia(LocalDateTime.parse(rs.getString("fecha_fin_vigencia"),DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
				mt.setFechaInactivacion(LocalDateTime.parse(rs.getString("fecha_inactivacion"),DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
				mt.setFechaInicioVigencia(LocalDateTime.parse(rs.getString("fecha_inicio_vigencia"),DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
				mt.setId(rs.getInt("id"));
				mt.setMonto(rs.getInt("monto"));
				Usuario inactivacion = new Usuario(rs.getInt("id_usuario_inactivacion"));
				mt.setUsuarioInactivacion(inactivacion);
				break;
				*/
				
				return getDatosFromDB(rs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);

		return mt;
	}

	@Override
	public MontoCuota insertar(MontoCuota cuota) {
		MontoCuota mtcuota = new MontoCuota();
		String query  = "INSERT INTO public.montos_cuota("
				+ "monto, "
				+ "fecha_creacion, "
				+ "fecha_inicio_vigencia, "
				+ "fecha_fin_vigencia, "
				+ "estado, "
				+ "fecha_inactivacion, "
				+ "id_usuario_inactivacion)"
				+ "	VALUES (?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement ps ;
		Connection con =  ConexionManager.obtenerConexionPostgres();
		try {
			ps = con.prepareStatement(query);
			ps.setDouble(1, cuota.getMonto());
			ps.setDate(2, Date.valueOf(cuota.getFechaCreacion().toLocalDate()));
			ps.setDate(3, Date.valueOf(cuota.getFechaInicioVigencia().toLocalDate()));
			ps.setDate(4, Date.valueOf(cuota.getFechaFinVigencia().toLocalDate()));
			ps.setString(5, cuota.getEstado());
			ps.setDate(6, Date.valueOf(cuota.getFechaInactivacion().toLocalDate()));
			ps.setInt(7, cuota.getUsuarioInactivacion().getId());
			ps.executeUpdate();
			mtcuota = cuota;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConexionManager.cerrarConexion(con);
		}
		
		return mtcuota;
	}

	@Override
	public MontoCuota modificar(MontoCuota objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void eliminar(MontoCuota objecto) {
		// TODO Auto-generated method stub

	}

	@Override
	public MontoCuota getMontoCuotaByAnho(int mes, int anho) {
		// TODO Auto-generated method stub
		return null;
	}

}
