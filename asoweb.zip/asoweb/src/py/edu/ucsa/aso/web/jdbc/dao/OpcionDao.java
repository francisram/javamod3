package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.Opcion;

public interface OpcionDao extends GenericDao<Opcion>{
	
	Opcion getOpcionByDominioCodOpcion(String dominio,String codOpcion);
	List<Opcion> getOpcionesByCodDominio(String dominio);
	List<Opcion> getOpcionesByIdDominio(Integer idDominio);

	@Override
	default List<Opcion> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Opcion getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Opcion insertar(Opcion objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default Opcion modificar(Opcion objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(Opcion objecto) {
		// TODO Auto-generated method stub
		
	}

	
}
