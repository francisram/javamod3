package py.edu.ucsa.aso.web.jdbc.dao.impl;

import py.edu.ucsa.aso.web.jdbc.dao.GenericDao;

public abstract class AbstractDao<T> implements GenericDao<T> {

}
