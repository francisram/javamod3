package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.MovimientoSocio;

public interface MovimientoSocioDao extends GenericDao<MovimientoSocio> {

	@Override
	default List<MovimientoSocio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MovimientoSocio getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MovimientoSocio insertar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default MovimientoSocio modificar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(MovimientoSocio objecto) {
		// TODO Auto-generated method stub
		
	}
	

}
