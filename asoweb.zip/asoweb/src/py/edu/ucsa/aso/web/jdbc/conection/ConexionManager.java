package py.edu.ucsa.aso.web.jdbc.conection;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionManager {
	private static Logger logger = Logger.getLogger(ConexionManager.class.getName());
	
	public static Connection  obtenerConexionPostgres() {
		return obtenerConexion("postgres");
	}
	
	public static Connection  obtenerConexionMysql() {
		return obtenerConexion("mysql");
	}
	
	public static Connection obtenerConexion(String fileName) {
		Connection con = null;
		try {
			ResourceBundle bundle  =  ResourceBundle.getBundle(fileName);
			con = DriverManager.getConnection(
					bundle.getString("jdbc.url"),
					bundle.getString("jdbc.user"),
					bundle.getString("jdbc.pass")
					);
			//System.out.println("Conectado a :" + con.getMetaData().getDatabaseProductName()+ " /database: "+ con.getSchema());
			//con.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return con;
	}
	
	public static Boolean cerrarConexion(Connection con) {
		try {
			if(Objects.nonNull(con) && !con.isClosed()) {
				try {
					con.close();
					return true;
				} catch (SQLException e) {
					logger.log(Level.SEVERE,e.getMessage());
					return false;
				}
			} 
		} catch (SQLException e) {
			return false;
		}
		return false;
	}

}
