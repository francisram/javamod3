package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.PagoOtroConcepto;

public interface PagoOtroConceptoDao extends GenericDao<PagoOtroConcepto> {

	@Override
	default List<PagoOtroConcepto> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoOtroConcepto getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoOtroConcepto insertar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default PagoOtroConcepto modificar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(PagoOtroConcepto objecto) {
		// TODO Auto-generated method stub
		
	}
	
	

}
