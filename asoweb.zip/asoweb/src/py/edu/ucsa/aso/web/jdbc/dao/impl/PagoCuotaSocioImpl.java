package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import py.edu.ucsa.aso.web.jdbc.conection.ConexionManager;
import py.edu.ucsa.aso.web.jdbc.dao.PagoCuotaSocioDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.MovimientoSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Opcion;
import py.edu.ucsa.aso.web.jdbc.dao.dto.PagoCuotaSocio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Socio;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class PagoCuotaSocioImpl implements PagoCuotaSocioDao {
	private static List<PagoCuotaSocio> pagosSocios;
	static Statement sts;

	@Override
	public List<PagoCuotaSocio> listar() {
		String query = "SELECT * FROM public.pagos_cuotas_socios\r\n"
				+ "ORDER BY id ASC ";

		Connection con = ConexionManager.obtenerConexionPostgres();
		try {
			sts = con.createStatement();
			ResultSet rs = sts.executeQuery(query);
			while (rs.next()) {
				// PagoCuotaSocio pCuota = getPagoCuotaFromDB(rs);
				getListaPagosCuotaSocios().add(getPagoCuotaFromDB(rs));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);
		return pagosSocios;
	}

	private PagoCuotaSocio getPagoCuotaFromDB(ResultSet rs) throws SQLException {
		PagoCuotaSocio pCuota = new PagoCuotaSocio();
		pCuota.setId(rs.getInt("id"));
		pCuota.setAnhoCuota(rs.getInt("anho_cuota"));
		pCuota.setExonerado(rs.getBoolean("exonerado"));
		pCuota.setFechaCreacion(rs.getDate("fecha_creacion"));
		pCuota.setMesCuota(rs.getInt("mes_cuota"));
		pCuota.setMontoCuota(rs.getDouble("monto_cuota"));
		Opcion estado = new Opcion(rs.getInt("id_estado"));
		pCuota.setIdEstado(estado);
		Opcion motivoExoneracion = new Opcion(rs.getInt("id_motivo_exoneracion"));
		pCuota.setMotivoExoneracion(motivoExoneracion);
		MovimientoSocio idMovimiento = new MovimientoSocio(rs.getInt("id_movimiento_socio"));
		pCuota.setMovimientoSocio(idMovimiento);
		Socio socio = new Socio(rs.getInt("id_socio"));
		pCuota.setSocio(socio);
		Usuario usuarioCreacion = new Usuario(rs.getInt("id_usuario_creacion"));
		pCuota.setUsuarioCreacion(usuarioCreacion);
		//System.out.println(pCuota);
		return pCuota;
	}

	public static List<PagoCuotaSocio> getListaPagosCuotaSocios() {
		if (Objects.isNull(pagosSocios)) {
			pagosSocios = new ArrayList<>();
		}
		return pagosSocios;
	}

	public List<PagoCuotaSocio> getPagosSocios() {
		return pagosSocios;
	}

	@Override
	public PagoCuotaSocio getById(Integer id) {
		PagoCuotaSocio pcuota = new PagoCuotaSocio();
		Connection con  = ConexionManager.obtenerConexionPostgres();
		try {
			String query = "select * from pagos_cuotas_socios where id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				pcuota = getPagoCuotaFromDB(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ConexionManager.cerrarConexion(con);
		
		return pcuota;
	}

	@Override
	public PagoCuotaSocio insertar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		return PagoCuotaSocioDao.super.insertar(objecto);
	}

	@Override
	public PagoCuotaSocio modificar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		return PagoCuotaSocioDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(PagoCuotaSocio objecto) {
		// TODO Auto-generated method stub
		PagoCuotaSocioDao.super.eliminar(objecto);
	}

}
