package py.edu.ucsa.aso.web.jdbc.dao;

import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.dto.TipoMovimiento;

public interface TipoMovimientoDao extends GenericDao<TipoMovimiento>{

	@Override
	default List<TipoMovimiento> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TipoMovimiento getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TipoMovimiento insertar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default TipoMovimiento modificar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	default void eliminar(TipoMovimiento objecto) {
		// TODO Auto-generated method stub
		
	}

}
