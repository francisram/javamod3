package py.edu.ucsa.aso.web.jdbc.dao.impl;

import java.sql.Statement;
import java.util.List;

import py.edu.ucsa.aso.web.jdbc.dao.MenuDao;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Menu;
import py.edu.ucsa.aso.web.jdbc.dao.dto.Usuario;

public class MenuImpl implements MenuDao {
	
	static Statement sts;
	private static List<Menu> menus;

	@Override
	public List<Menu> listar() {
		// TODO Auto-generated method stub
		return MenuDao.super.listar();
	}

	@Override
	public Menu getById(Integer id) {
		// TODO Auto-generated method stub
		return MenuDao.super.getById(id);
	}

	@Override
	public Menu insertar(Menu objecto) {
		// TODO Auto-generated method stub
		return MenuDao.super.insertar(objecto);
	}

	@Override
	public Menu modificar(Menu objecto) {
		// TODO Auto-generated method stub
		return MenuDao.super.modificar(objecto);
	}

	@Override
	public void eliminar(Menu objecto) {
		// TODO Auto-generated method stub
		MenuDao.super.eliminar(objecto);
	}

}
