/**
 * 
 */
/**
 * @author frlopez
 *
 */
module asoweb {
	requires java.sql;
}